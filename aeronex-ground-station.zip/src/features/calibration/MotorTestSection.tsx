import { Fan, OctagonX, Play, Square, TriangleAlert, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { commandLink } from "../../services/link/commandLink";
import { useLink } from "../../state/linkStore";

/*
  Per-motor spin test (MAV_CMD_DO_MOTOR_TEST). Each motor has a throttle slider;
  while a motor is "spinning" we resend the command on a timer shorter than its
  timeout, so the motor keeps turning at the slider value but stops on its own if
  anything interrupts the GCS (dead-man safety). Gated on disarmed + props-off.
*/

const RESEND_MS = 1200;
const TIMEOUT_S = 3; // each command self-expires after this
const STEP_MS = 2200; // how long each motor runs in the sequence test
const LETTERS = "ABCDEFGH".split("");

export function MotorTestSection({ canSend }: { canSend: boolean }) {
  const armed = useLink((s) => s.vehicle?.armed) ?? false;
  const [count, setCount] = useState(4);
  const [throttle, setThrottle] = useState<number[]>(() => Array(8).fill(8));
  const [spinning, setSpinning] = useState<boolean[]>(() => Array(8).fill(false));
  const [propsOff, setPropsOff] = useState(false);
  const [seqRunning, setSeqRunning] = useState(false);
  const [seqIndex, setSeqIndex] = useState(-1);

  const throttleRef = useRef(throttle);
  const spinningRef = useRef(spinning);
  const seqAbort = useRef(false);
  throttleRef.current = throttle;
  spinningRef.current = spinning;

  const blocked = !canSend || armed || !propsOff;

  const stopAll = (send = true) => {
    seqAbort.current = true;
    setSeqRunning(false);
    setSeqIndex(-1);
    setSpinning(Array(8).fill(false));
    if (send && canSend) void commandLink.stopAllMotors(count);
  };

  // Resend loop: keep every spinning motor alive at its current throttle.
  useEffect(() => {
    const id = setInterval(() => {
      if (blocked) return;
      for (let i = 0; i < count; i++) {
        if (spinningRef.current[i]) void commandLink.motorTest(i + 1, throttleRef.current[i], TIMEOUT_S);
      }
    }, RESEND_MS);
    return () => clearInterval(id);
  }, [blocked, count]);

  // Safety: cut everything if the link drops, the vehicle arms, or props-off is unchecked.
  useEffect(() => {
    if (blocked && spinningRef.current.some(Boolean)) stopAll(canSend);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [blocked]);

  // Stop on unmount.
  useEffect(() => () => void (canSend && commandLink.stopAllMotors(8)), [canSend]);

  const toggle = (i: number) => {
    if (seqRunning) return;
    setSpinning((prev) => {
      const next = [...prev];
      next[i] = !prev[i];
      if (next[i]) void commandLink.motorTest(i + 1, throttleRef.current[i], TIMEOUT_S);
      else void commandLink.stopMotor(i + 1);
      return next;
    });
  };

  const setThr = (i: number, v: number) => {
    setThrottle((prev) => {
      const next = [...prev];
      next[i] = v;
      return next;
    });
    if (spinningRef.current[i] && !blocked) void commandLink.motorTest(i + 1, v, TIMEOUT_S);
  };

  // Step through every motor one at a time, lighting the active card as it goes.
  const sequence = async () => {
    if (blocked || seqRunning) return;
    seqAbort.current = false;
    setSeqRunning(true);
    for (let i = 0; i < count; i++) {
      if (seqAbort.current || blocked) break;
      setSeqIndex(i);
      setSpinning(() => {
        const n = Array(8).fill(false);
        n[i] = true;
        return n;
      });
      void commandLink.motorTest(i + 1, throttleRef.current[i], TIMEOUT_S);
      const started = Date.now();
      while (Date.now() - started < STEP_MS) {
        if (seqAbort.current) break;
        await new Promise((r) => setTimeout(r, 120));
      }
    }
    setSpinning(Array(8).fill(false));
    setSeqIndex(-1);
    setSeqRunning(false);
    if (canSend) void commandLink.stopAllMotors(count);
  };

  const anySpinning = spinning.some(Boolean);
  const busy = anySpinning || seqRunning;

  return (
    <div className="cal-section">
      <div className="cal-sec-head">
        <div>
          <h2>Motor test</h2>
          <p>Spin each motor on its own to check wiring order and direction. Drag a slider to set its speed — the motor stops by itself the instant anything interrupts the link.</p>
        </div>
        <Fan className="cal-sec-icon" />
      </div>

      <div className="callout danger">
        <TriangleAlert />
        <span><strong>Remove all propellers first.</strong> Motors spin at the commanded throttle immediately. Confirm the aircraft is secured and clear of people.</span>
      </div>
      {armed && <div className="callout warn"><X /><span>Disarm the vehicle to run a motor test.</span></div>}
      {!canSend && <div className="callout warn"><X /><span>Connect a vehicle to test motors.</span></div>}

      <section className="panel">
        <div className="panel-head">
          <h3>Motors</h3>
          <div className="cal-actions tight">
            <label className="mt-count">
              Motors
              <select className="select" value={count} onChange={(e) => { stopAll(); setCount(Number(e.target.value)); }} disabled={busy}>
                {[3, 4, 6, 8].map((n) => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </label>
            <button className="btn btn-danger" onClick={() => stopAll()} disabled={!canSend}>
              <OctagonX /> Stop all
            </button>
          </div>
        </div>
        <div className="panel-body cal-body">
          <label className="esc-confirm">
            <input type="checkbox" checked={propsOff} onChange={(e) => { setPropsOff(e.target.checked); if (!e.target.checked) stopAll(); }} />
            <span>I have removed all propellers and the area is clear.</span>
          </label>

          {seqRunning && (
            <div className="callout accent">
              <Fan size={16} className="spin" />
              <span>Sequence running — <strong>Motor {LETTERS[seqIndex] ?? "?"}</strong> ({seqIndex + 1} of {count}). Watch that each motor spins in turn, in the direction marked for its position.</span>
            </div>
          )}

          <div className="mt-grid">
            {Array.from({ length: count }, (_, i) => (
              <div key={i} className={`mt-motor${spinning[i] ? " live" : ""}`}>
                <div className="mt-head">
                  <span className="mt-letter">{LETTERS[i]}</span>
                  <span className="mt-num">Motor {i + 1}</span>
                  {spinning[i] && <span className="mt-spin"><Fan size={14} className="spin" /></span>}
                </div>
                <div className="mt-slider">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={1}
                    value={throttle[i]}
                    disabled={blocked || seqRunning}
                    onChange={(e) => setThr(i, Number(e.target.value))}
                  />
                  <span className="mt-pct">{throttle[i]}%</span>
                </div>
                <button className={`btn ${spinning[i] ? "btn-danger" : "btn-primary"}`} disabled={blocked || seqRunning} onClick={() => toggle(i)}>
                  {spinning[i] ? <><X /> Stop</> : <><Play /> Spin</>}
                </button>
              </div>
            ))}
          </div>

          <div className="cal-actions">
            {!seqRunning ? (
              <button className="btn" disabled={blocked || anySpinning} onClick={() => void sequence()}>
                <Play /> Test in sequence (A → {LETTERS[count - 1]})
              </button>
            ) : (
              <button className="btn btn-danger" onClick={() => stopAll()}>
                <Square /> Stop sequence
              </button>
            )}
          </div>
          <p className="muted" style={{ fontSize: "var(--t-xs)" }}>
            Motor A should be the one the firmware lists first for your frame; confirm each spins in the direction marked for its position. Keep throttle low — just enough to turn the motor. On the bench you need a battery connected (props off) for the motors to actually turn.
          </p>
        </div>
      </section>
    </div>
  );
}
